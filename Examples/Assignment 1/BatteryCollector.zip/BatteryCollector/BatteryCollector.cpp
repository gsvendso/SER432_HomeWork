// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "BatteryCollector.h"


IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, BatteryCollector, "BatteryCollector" );
 
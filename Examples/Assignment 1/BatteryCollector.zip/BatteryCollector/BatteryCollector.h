// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#ifndef __BATTERYCOLLECTOR_H__
#define __BATTERYCOLLECTOR_H__

#include "Engine.h"

#endif
